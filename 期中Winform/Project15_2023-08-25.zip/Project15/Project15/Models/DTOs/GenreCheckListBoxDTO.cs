﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project15.Models.DTOs
{
	public class GenreCheckListBoxDTO
	{
		public int ID { get; set; }
		public string Name { get; set; }
		public bool IsSelected { get; set; }
	}
}
