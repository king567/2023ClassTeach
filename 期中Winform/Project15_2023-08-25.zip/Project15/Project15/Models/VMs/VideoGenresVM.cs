﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace Project15.Models.VMs
{
	public class VideoGenresVM
	{
		public int Id { get; set; }
		public string Name { get; set; }
	}
}
